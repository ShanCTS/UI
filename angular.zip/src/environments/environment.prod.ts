export const environment = {
  production: true,
  url : "http://localhost/CoreApi/api/"
};
