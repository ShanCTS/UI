import { Component, OnInit } from '@angular/core';
import { CoreService } from '../../service-module.service';
import { Project } from '../../model/project';
import { User } from '../../model/user';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  // Properties
  projectdata = new Project();
  user = new User();
  
  isAdd: boolean;
  isUpdate: boolean;
  
  error : any = { errorMessage: "", hasErrors : false };
  
  isSubmit:boolean;  
  modelRef: NgbModalRef;

  isCheckBoxEnabled : boolean;

  @Input()
  set projectUpdate(project:Project)
  {
    if (project != null) {
      this.isUpdate = true;
      this.isCheckBoxEnabled = project.StartDate != null && project.EndDate != null;

      this.projectdata.Id = project.Id;
      this.projectdata.Name = project.Name;      
      this.projectdata.StartDate = project.StartDate;
      this.projectdata.EndDate = project.EndDate;     
      this.projectdata.Priority = project.Priority;   

      this.user = project.SelectedUser != null ? project.SelectedUser : new User();
      this.ToggleDates();
    }
  }


  constructor(private service: CoreService, private modalService: NgbModal, private datePipeControl : DatePipe) { }

  ngOnInit() {
  }


  @Output()
  projectSubmit = new EventEmitter();

  openModal(content) {
    this.modelRef = this.modalService.open(content);   
  }

  ToggleDates(){
    if(this.isCheckBoxEnabled)
    {
      var date = new Date();
      var enddate = new Date();
      enddate.setDate(date.getDate() + 1);

      if(this.isUpdate && this.projectdata.StartDate != null)
      {
        this.projectdata.StartDate = this.datePipeControl.transform(this.projectdata.StartDate, "yyyy-MM-dd");
      }
      else{
        this.projectdata.StartDate = this.datePipeControl.transform( date, "yyyy-MM-dd");
      }
      
      if(this.isUpdate && this.projectdata.EndDate != null)
      {
        this.projectdata.EndDate = this.datePipeControl.transform(this.projectdata.EndDate, "yyyy-MM-dd");
      }
      else{
        this.projectdata.EndDate = this.datePipeControl.transform(enddate, "yyyy-MM-dd");
      }
    }
    else{
      this.projectdata.StartDate = null;
      this.projectdata.EndDate = null;
      this.error = { isError: false, errorMessage: '' };
    }
  }

  DateValidator(): void {

    this.error = { hasErrors: false, errorMessage: '' };

    if (this.isCheckBoxEnabled) {
      if (this.projectdata.StartDate.length == 0) {
        this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
      }
      else if (this.projectdata.EndDate.length == 0) {
        this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
      }
    }
    if (!this.error.hasErrors) {
      if (new Date(this.projectdata.StartDate) > new Date(this.projectdata.EndDate)) {
        this.error = { hasErrors: true, errorMessage: 'End Date can not before start date' };
      }
    }
  }
  
  refreshManager(selectedData) {
    
    if(this.projectdata.SelectedUser == null)
    {
      this.projectdata.SelectedUser = new User();
    }
    this.projectdata.SelectedUser.Id = selectedData.id;
    this.user.Name = selectedData.value;
    this.user.Id = selectedData.id;
    this.closeModal();
  }

  cancelEdit() {
    this.isUpdate = false;
    this.resetForm();
  }

  closeModal() {    
    this.modelRef.close();
  }

  onSubmit()
  {
    this.isSubmit = true;

    let newproject = {
      Id : this.projectdata.Id,
      Name : this.projectdata.Name,
      StartDate : this.projectdata.StartDate,
      EndDate : this.projectdata.EndDate,
      Priority : this.projectdata.Priority,
      SelectedUser : this.user
    }

    this.service.post("projects/save", newproject).subscribe(() => {
      this.resetForm();
      this.projectSubmit.emit();
      if (!this.isUpdate) {
      alert("Project created successfully");
      }else{
        alert("Project updated successfully");
      }
    });
  }


  resetForm() {
    this.projectdata = new Project();
    this.user = new User();
    this.isCheckBoxEnabled = false;
    this.ToggleDates();
  }
}
