import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectComponent } from './project.component';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http/src/client';
import { AddProjectComponent } from './add-project/add-project.component';
import { ModalTemplateComponent } from '../shared/modal-template/modal-template.component';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';

describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let fixture: ComponentFixture<ProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectComponent, AddProjectComponent, ModalTemplateComponent ],
      imports : [ FormsModule, HttpClientModule ],
      providers : [ DatePipe ]
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
