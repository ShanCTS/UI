import { Component, OnInit } from '@angular/core';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CoreService } from '../service-module.service';
import { ActivatedRoute } from '@angular/router';
import { Task } from '../model/task';
import { Project } from '../model/project';
import * as _ from 'lodash';
import { validateConfig } from '@angular/router/src/config';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {

  modelRef: NgbModalRef;

  constructor(private service: CoreService,
    private modalService: NgbModal,
    private route: ActivatedRoute) { }

  Project = null; 
  modal;
  sortedBy;
  sortedOrder;
  Tasks : Task[];

  ngOnInit() {
    var id = this.route.snapshot.params['id'];
    if (id != null) {
      this.service.get<Project>("projects/get", id).subscribe(data => {
        this.Project = data[0];
        this.Tasks = this.Project.Tasks;
        //this.GetTasks(id);
      });
    }
  }

  openModal(content) {
    this.modelRef = this.modalService.open(content);    
  }

  GetTasks(id){
    this.service.get<Project>("projects/get", id).subscribe(value => {
      console.log(value);
      this.Project = value[0];
      this.Tasks = value[0].Tasks;
    });
  }

  sortTasks(sortBy: string, sortOrder) {
    if (!(sortOrder != null && this.sortedBy != sortBy)) {
      sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    }
    this.Tasks = _.orderBy(this.Tasks, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  endTask(taskId) {
    this.service.post("tasks/delete", taskId).subscribe(
      () => {
        alert("Task ended successfully");
        this.GetTasks(this.Project.Id);
      });
  }

  ProjectSearch(data){
    this.Project = { Id: data.id, Name: data.value };
    this.GetTasks(data.id);
    this.closeModal();
  }

  closeModal() {
    this.modelRef.close();
  }
}
