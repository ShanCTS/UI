import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { ProjectComponent } from './project/project.component';
import { AddProjectComponent } from './project/add-project/add-project.component';
import { TaskComponent } from './task/task.component';
import { ViewTaskComponent } from './view-task/view-task.component';

const routes: Routes = [
  { path: '', redirectTo: "/user", pathMatch: "full" },
  { path: 'user', component: UserComponent },
  { path: 'project', component: ProjectComponent },
  { path: 'addtask', component: TaskComponent },
  { path: 'updatetask/:id', component: TaskComponent },
  { path: 'viewtask', component: ViewTaskComponent }  ,
  { path: 'view-task/:id', component: ViewTaskComponent }  
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
