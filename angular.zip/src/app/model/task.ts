import { Project } from "./project";
import { User } from "./user";

export class Task{
    Id : number;
    ParentId : number;
    ProjectId : number;
    Description : string;
    StartDate : string;
    EndDate : string;
    Priority : number;
    TotalTasks : number;
    IsParentTask : boolean;
    Status : string;
    ProjectName : string;
    ParentTaskName : string

    Project : Project;
    User: User;
}