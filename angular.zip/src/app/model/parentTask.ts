import { Task } from "./task";

export class ParentTask{
    Id : number;   
    Description : string

    Tasks: Task[];
}
    