import { Project } from "./project";

export class User{
    Id : number;
    Name: string;
        FirstName : string;
        LastName : string;
        EmployeeId : number;
        ProjectId : number;

        Project : Project;
}