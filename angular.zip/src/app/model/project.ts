import { Task } from "./task";
import { User } from "./user";

export class Project{
        Id : number;
        Name : string;
        StartDate : string;
        EndDate : string;
        Priority : number;
        TotalTasks : number;
        CompletedTasks : number;
        Tasks : Task[];        
        Users : User[];
        SelectedUser : User;
}