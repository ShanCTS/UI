import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { IfStmt } from '@angular/compiler';
import { CoreService } from '../../service-module.service';
import { User } from '../../model/user';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user = new User();
  isUpdate = false;
  submitted = false;

  constructor(private service : CoreService) { }

  ngOnInit() {

  }

  @Output()
  userSubmit = new EventEmitter();

  @Input()
  set userdata(user) {
      if (user != null) {
        this.isUpdate = true;
        this.user = user;
      }
  }
  
  OnSubmit() {
      
    let user = {
        Id : this.user.Id,
        FirstName : this.user.FirstName,
        LastName : this.user.LastName,
        EmployeeId : this.user.EmployeeId        
      }

      this.service.post("users/save", user)
              .subscribe(() => {
                  this.resetForm();
                  this.userSubmit.emit();                  
                  alert(this.isUpdate ? "User updated successfully" : "User created successfully");
                  this.isUpdate = false;
              });      
      
  }
  cancelEdit() {
      this.isUpdate = false;
      this.resetForm();
  }

  resetForm() {
      this.submitted = false;
      this.user = new User();
  }

}
