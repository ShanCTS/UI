import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { CoreService } from '../service-module.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users : User[];
  user :User;
  sortedBy: string;
  sortedOrder: string;

  constructor(private service : CoreService) { }

  ngOnInit() {
    this.GetUsers();
  }

  GetUsers()  {
    this.service.get<User[]>("users/get", "0").subscribe(data => this.users = data);
  }

  editUser(user: User) {
    this.user = user;    
  }

  deleteUser(id: number) {    
    this.service.post("users/delete", id).subscribe(() => {        
        this.GetUsers();
        alert("User deleted successfully");        
      });
  }

  sortUsers(sortBy: string) {
    var sortOrder = this.sortedBy != sortBy || this.sortedOrder == "desc" ? "asc" : "desc";
    this.users = _.orderBy(this.users, [sortBy], [sortOrder]);
    this.sortedBy = sortBy;
    this.sortedOrder = sortOrder;
  }

  searchUsers(searchText) {
    this.service.get<User[]>("users/search", searchText == null || searchText == "" ? "0" : searchText).subscribe(data => { this.users = data; });
  }
}
