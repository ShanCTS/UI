import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CoreService } from '../../service-module.service';
import { User } from '../../model/user';
import * as _ from 'lodash';
import { Project } from '../../model/project';
import { Task } from '../../model/task';

@Component({
  selector: 'app-modal-template',
  templateUrl: './modal-template.component.html',
  styleUrls: ['./modal-template.component.css']
})
export class ModalTemplateComponent implements OnInit {

  lookups: { id: number, value: string }[] = [];
  allLookups;
  closeBtnName = "Close";

  @Output()
  closeClick = new EventEmitter();

  @Input()
  lookupFor: string;

  @Output()
  OnDataSelect = new EventEmitter();

  constructor(private service : CoreService) { }

  ngOnInit() {
    switch (this.lookupFor) {

      case "Project":
        this.service.get<Project[]>("projects/get", "0")
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.Id, value: m.Name });
            });
          });
        break;

      case "User":
        this.service.get<User[]>("users/get", '0')
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.Id, value: m.Name });
            });
          });
        break;

      case "ParentTask":
        this.service.get<Task[]>("tasks/parent-task/get",'0')
          .subscribe(data => {
            _.forEach(data, (m) => {
              this.lookups.push({ id: m.Id, value: m.Description });
            });
          });
        break;
    }

    this.allLookups = this.lookups;
  }

  searchLookup(searchText) {
    this.lookups = _.filter(this.allLookups,
      (m) => m.value.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)
  }

  selectLookup(lookup) {
    this.OnDataSelect.emit(lookup)
  }

  closeModal() {
    this.closeClick.emit();
  }

}
