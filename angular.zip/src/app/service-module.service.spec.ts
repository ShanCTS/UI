import { TestBed } from '@angular/core/testing';

import { CoreService } from './service-module.service';
import { HttpClientModule } from '@angular/common/http';

describe('ServiceModuleService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [ HttpClientModule ]
  }));

  it('should be created', () => {
    const service: CoreService = TestBed.get(CoreService);
    expect(service).toBeTruthy();
  });
});
