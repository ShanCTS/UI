import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from '../environments/environment.prod';

@Injectable({
  providedIn: 'root'
})

export class CoreService {

  baseUrl = "";
  data : any;
  constructor(public service : HttpClient) {
    this.baseUrl = environment.url;
   }

   get<T>(apiCall : string, query: string) : Observable<T>{
      var api = query != null && query != undefined ? this.baseUrl + apiCall + "/" + query : this.baseUrl;
      this.data = this.service.get<T>(api);
      return this.data;
   }

   post(apiCall : string, request : any) : Observable<any>{
    var api = this.baseUrl + apiCall;
    this.data = this.service.post<any>(api, request);
    return this.data;
   }
}
