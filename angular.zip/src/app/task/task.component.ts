import { Component, OnInit } from '@angular/core';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { User } from '../model/user';
import { Task } from '../model/task';
import { Project } from '../model/project';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CoreService } from '../service-module.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { getIsParent } from '@angular/core/src/render3/state';
import { ParentTask } from '../model/parentTask';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  isParentTask : boolean;
  Project = new Project();
  Task = new Task();
  user = new User();
  ParentTask = new ParentTask();
  Submitted : boolean;
  isUpdate : boolean;
  error : any = { errorMessage: "", hasErrors : false };
  modelRef : NgbModalRef ;

  constructor(private modalService: NgbModal, 
    private service : CoreService,
    private router: Router,
    private route: ActivatedRoute,
    private dateControl: DatePipe) { }

  ngOnInit() {
    this.ToggleDates();
    if (this.route.snapshot.params['id'] != null) {
      this.isUpdate = true;
      this.GetTask(this.route.snapshot.params['id']);
    }    
  }

  GetTask(id){
    this.service.get<Task>("tasks/get", id).subscribe(value => {
      console.log(value);
      value = value[0];
      this.Task = value;
      this.Project.Name = value.Project.Name;
      this.Project.Id = value.Project.Id;
      this.ParentTask = new ParentTask();
      this.ParentTask.Id = value.ParentId;
      this.ParentTask.Description = value.ParentTaskName
      this.user = value.User != null ? value.User : new User();;
      this.ToggleDates();
    });
  }

  ToggleDates(){
    if(!this.isParentTask)
    {
      var date = new Date();
      var enddate = new Date();
      enddate.setDate(date.getDate() + 1);
      this.Task.StartDate = this.dateControl.transform(this.isUpdate ? this.Task.StartDate : date, "yyyy-MM-dd");
      this.Task.EndDate = this.dateControl.transform(this.isUpdate ? this.Task.EndDate : enddate, "yyyy-MM-dd");
    }
    else{
      this.Task.StartDate = null;
      this.Task.EndDate = null;
      this.Task.ParentId = null;
      this.Task.ParentTaskName = null;
      this.user.Id = 0;
      this.user.Name = null
      this.error = { isError: false, errorMessage: '' };
    }
  }

  closeResult;

  openModal(content) {
    this.modelRef = this.modalService.open(content);
    this.modelRef.result.then((result) => {      
    }, (reason) => {      
    });
  }

  refreshProject(selectedData){
    this.Project.Name = selectedData.value;    
    this.Project.Id = selectedData.id;
    this.closeModal();
  }

  refreshParentTask(selectedData){
    this.ParentTask.Id = selectedData.id;
    this.ParentTask.Description = selectedData.value;
    this.Task.ParentTaskName = selectedData.value;
    this.closeModal();
  }

  refreshUser(selectedData){
    this.user.Id = selectedData.id;
    this.user.Name = selectedData.value;
    this.closeModal();
  }

  DateValidator(): void {

    this.error = { hasErrors: false, errorMessage: '' };

    if (this.Task.StartDate.length == 0) {
      this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
    }
    else if (this.Task.EndDate.length == 0) {
      this.error = { hasErrors: true, errorMessage: 'Both Start Date and End Date are required!' };
    }
    if (!this.error.hasErrors) {
      if (new Date(this.Task.StartDate) > new Date(this.Task.EndDate)) {
        this.error = { hasErrors: true, errorMessage: 'End Date can not before start date' };
      }
    }
  }

  onSubmit()
  {
    let Task = {
      ParentId : this.ParentTask.Id,
      ParentTaskName : this.Task.ParentTaskName,
      Id : this.Task.Id,
      Task : this.Task.Description,
      Description : this.Task.Description,
      StartDate: this.Task.StartDate,
      EndDate : this.Task.EndDate,
      Priority: this.Task.Priority,
      IsParentTask: this.isParentTask,
      ProjectId: this.Project.Id,
      User: this.user,
      UserId : this.user.Id
    };
    
    this.service.post("tasks/save", Task)
    .subscribe(() => {
      alert(this.isUpdate ? "Task updated successfully" : "Task created successfully");
      if(!this.isParentTask)
      {
        this.router.navigate(["/view-task", this.Project.Id]);
      }
    });   
  }

  closeModal() {    
    this.modelRef.close();
  }

  ResetForm(){
    this.Task = new Task();
    this.isParentTask = false;
    this.user = new User();    
  }

}
